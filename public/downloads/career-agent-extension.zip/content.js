"use strict";
(() => {
  // src/lib/countries.ts
  var COUNTRIES = [
    { code: "in", name: "India", currency: "INR", adzuna: true },
    { code: "sg", name: "Singapore", currency: "SGD", adzuna: true },
    { code: "ae", name: "United Arab Emirates", currency: "AED", adzuna: false },
    { code: "au", name: "Australia", currency: "AUD", adzuna: true },
    { code: "nz", name: "New Zealand", currency: "NZD", adzuna: true },
    { code: "gb", name: "United Kingdom", currency: "GBP", adzuna: true },
    { code: "ie", name: "Ireland", currency: "EUR", adzuna: false },
    { code: "us", name: "United States", currency: "USD", adzuna: true },
    { code: "ca", name: "Canada", currency: "CAD", adzuna: true },
    { code: "de", name: "Germany", currency: "EUR", adzuna: true },
    { code: "nl", name: "Netherlands", currency: "EUR", adzuna: true },
    { code: "fr", name: "France", currency: "EUR", adzuna: true },
    { code: "es", name: "Spain", currency: "EUR", adzuna: true },
    { code: "it", name: "Italy", currency: "EUR", adzuna: true },
    { code: "ch", name: "Switzerland", currency: "CHF", adzuna: true },
    { code: "at", name: "Austria", currency: "EUR", adzuna: true },
    { code: "be", name: "Belgium", currency: "EUR", adzuna: true },
    { code: "pl", name: "Poland", currency: "PLN", adzuna: true },
    { code: "za", name: "South Africa", currency: "ZAR", adzuna: true },
    { code: "br", name: "Brazil", currency: "BRL", adzuna: true },
    { code: "mx", name: "Mexico", currency: "MXN", adzuna: true },
    { code: "hk", name: "Hong Kong", currency: "HKD", adzuna: false },
    { code: "my", name: "Malaysia", currency: "MYR", adzuna: false },
    { code: "jp", name: "Japan", currency: "JPY", adzuna: false },
    { code: "qa", name: "Qatar", currency: "QAR", adzuna: false },
    { code: "sa", name: "Saudi Arabia", currency: "SAR", adzuna: false },
    { code: "id", name: "Indonesia", currency: "IDR", adzuna: false },
    { code: "ph", name: "Philippines", currency: "PHP", adzuna: false },
    { code: "th", name: "Thailand", currency: "THB", adzuna: false },
    { code: "vn", name: "Vietnam", currency: "VND", adzuna: false },
    { code: "se", name: "Sweden", currency: "SEK", adzuna: false },
    { code: "dk", name: "Denmark", currency: "DKK", adzuna: false },
    { code: "no", name: "Norway", currency: "NOK", adzuna: false },
    { code: "fi", name: "Finland", currency: "EUR", adzuna: false },
    { code: "pt", name: "Portugal", currency: "EUR", adzuna: false },
    { code: "cz", name: "Czechia", currency: "CZK", adzuna: false },
    { code: "hu", name: "Hungary", currency: "HUF", adzuna: false },
    { code: "ro", name: "Romania", currency: "RON", adzuna: false },
    { code: "gr", name: "Greece", currency: "EUR", adzuna: false },
    { code: "lu", name: "Luxembourg", currency: "EUR", adzuna: false },
    { code: "kr", name: "South Korea", currency: "KRW", adzuna: false },
    { code: "tw", name: "Taiwan", currency: "TWD", adzuna: false },
    { code: "tr", name: "Turkey", currency: "TRY", adzuna: false },
    { code: "il", name: "Israel", currency: "ILS", adzuna: false },
    { code: "kw", name: "Kuwait", currency: "KWD", adzuna: false },
    { code: "bh", name: "Bahrain", currency: "BHD", adzuna: false },
    { code: "om", name: "Oman", currency: "OMR", adzuna: false },
    { code: "lk", name: "Sri Lanka", currency: "LKR", adzuna: false },
    { code: "bd", name: "Bangladesh", currency: "BDT", adzuna: false },
    { code: "pk", name: "Pakistan", currency: "PKR", adzuna: false },
    { code: "np", name: "Nepal", currency: "NPR", adzuna: false },
    { code: "ng", name: "Nigeria", currency: "NGN", adzuna: false },
    { code: "ke", name: "Kenya", currency: "KES", adzuna: false },
    { code: "eg", name: "Egypt", currency: "EGP", adzuna: false },
    { code: "ar", name: "Argentina", currency: "ARS", adzuna: false },
    { code: "cl", name: "Chile", currency: "CLP", adzuna: false },
    { code: "co", name: "Colombia", currency: "COP", adzuna: false },
    { code: "pe", name: "Peru", currency: "PEN", adzuna: false }
  ];
  var COUNTRY_NAME_MAP = Object.fromEntries(COUNTRIES.map((c) => [c.code, c.name]));

  // src/lib/apply/country-scope.ts
  var NAMES = new Map(COUNTRIES.map((c) => [c.name.toLowerCase(), c.code]));

  // src/lib/apply/answers.ts
  var NOW_YEAR = () => (/* @__PURE__ */ new Date()).getFullYear();
  function estimateYears(experience, nowYear = NOW_YEAR()) {
    let min = Infinity, max = -Infinity;
    for (const e of experience) {
      const start = e.start?.match(/\b(19|20)\d{2}\b/)?.[0];
      const end = /present|current|now|till date/i.test(e.end ?? "") ? String(nowYear) : e.end?.match(/\b(19|20)\d{2}\b/)?.[0];
      if (start) min = Math.min(min, +start);
      if (end) max = Math.max(max, +end);
    }
    return Number.isFinite(min) && Number.isFinite(max) && max >= min ? max - min : null;
  }

  // src/lib/apply/skill-years.ts
  var ALIASES = { "amazon web services": "aws", "google cloud platform": "gcp", "google cloud": "gcp", "ms excel": "excel", "ms office": "office", "ms project": "project", "node js": "node", nodejs: "node", "react js": "react", reactjs: "react", "power bi": "powerbi", "sql server": "sqlserver" };
  var FILLER = /^(the|a|an|using|use of|of|with|in|on|at)\s+/;
  function yearsSkill(label) {
    const l = label.replace(/[*✱?]+/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
    if (!/\byears?\b/.test(l) && !/\bexperience\b/.test(l)) return null;
    const m = l.match(/(?:years?|yrs?)\b.{0,40}?\b(?:experience|exp|expertise|work(?:ed|ing)?|hands[- ]on)\b.{0,30}?\b(?:with|in|using|on|of|as)\s+(.{2,120})$/) ?? l.match(/\bexperience\b.{0,30}?\b(?:with|in|using|on)\s+(.{2,120}?)\s*\(?(?:in )?(?:number of )?years?\)?$/) ?? l.match(/^(.{2,120}?)\s+(?:experience|expertise)\s*\(?(?:in )?years?\)?$/) ?? l.match(/(?:years?|yrs?)\s+(?:with|in|using|of)\s+(.{2,120})$/);
    if (!m) return null;
    let s = m[1].replace(/\b(do|did|have|you|your|please|required|total|professional|relevant|overall)\b/g, " ").replace(/[^a-z0-9+#.,\- ]/g, " ").replace(/\s*,\s*/g, ", ").replace(/\s+/g, " ").trim();
    s = s.replace(FILLER, "").replace(/^microsoft\s+/, "").replace(/\s+(experience|skills?|platform|technology|tools?)$/, "").trim();
    s = ALIASES[s] ?? s;
    return s.length >= 2 && s.length <= 100 ? s : null;
  }
  var yearOf = (s, nowYear) => {
    if (!s) return null;
    if (/present|current|now|till date/i.test(s)) return nowYear;
    const y = s.match(/\b(19|20)\d{2}\b/)?.[0];
    return y ? +y : null;
  };
  var STOP = /* @__PURE__ */ new Set(["designing", "delivering", "design", "deliver", "managing", "leading", "building", "using", "developing", "implementing", "running", "experience", "initiatives", "projects", "programs", "programmes", "working", "handling", "driving", "creating", "and", "or", "of", "the", "in", "with", "for", "to", "a", "an"]);
  function termsOf(skill) {
    const chunks = skill.split(/,|\s+(?:and|or)\s+/).map((c) => c.split(/\s+/).filter((w) => w && !STOP.has(w)).join(" ")).filter((c) => c.length >= 2);
    return chunks.length ? chunks : [skill];
  }
  var esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  var wordPattern = (w) => w.length > 5 ? `${esc(w.replace(/(ings?|ments?|ed|es|s)$/, ""))}\\w*` : `${esc(w)}\\b`;
  var termRegex = (term) => new RegExp(`(^|[^a-z0-9])${term.split(/[\s-]+/).map(wordPattern).join("[\\s-]+")}`, "i");
  function skillYears(p, skill, nowYear = (/* @__PURE__ */ new Date()).getFullYear()) {
    const alias = Object.entries(ALIASES).filter(([, v]) => v === skill).map(([k]) => k);
    const terms = [...new Set([skill, ...alias].flatMap(termsOf))].map(termRegex);
    let min = Infinity, max = -Infinity;
    for (const e of p.experience) {
      const text2 = [e.title, ...e.bullets.map((b) => b.text)].join(" \n ");
      if (!terms.some((re) => re.test(text2))) continue;
      const start = yearOf(e.start, nowYear), end = yearOf(e.end, nowYear);
      if (start !== null) min = Math.min(min, start);
      if (end !== null) max = Math.max(max, end);
      else if (start !== null) max = Math.max(max, start);
    }
    if (!Number.isFinite(min) || !Number.isFinite(max)) return null;
    return String(Math.max(1, max - min));
  }
  function asCount(value) {
    const m = value.match(/\d+(?:\.\d+)?/);
    return m ? m[0] : value;
  }
  var wantsNumber = (label) => yearsSkill(label) !== null || /^\s*(how many|number of|total (years|number))\b/i.test(label.replace(/^[^a-z]+/i, ""));
  var AI_TOOL = /\b(ai|a\.i\.|genai|gen ai|generative ai|artificial intelligence|llms?|large language models?|gpt|chatgpt|openai|copilot|claude|gemini|anthropic|langchain|rag|prompt engineering|machine learning|ml|nlp|agentic|ai agents?|mcp|vector databases?|hugging ?face|diffusion|computer vision|deep learning|neural networks?)\b/i;
  var AI_TOOL_YEARS = 3;
  var GENERIC_TOOL_YEARS = 12;
  function defaultToolYears(p, skill, nowYear = (/* @__PURE__ */ new Date()).getFullYear()) {
    if (AI_TOOL.test(skill)) return String(AI_TOOL_YEARS);
    const career = estimateYears(p.experience, nowYear);
    return String(career === null ? 10 : Math.max(1, Math.min(GENERIC_TOOL_YEARS, career)));
  }

  // src/lib/apply/languages.ts
  var LANGUAGES = {
    english: ["english"],
    hindi: ["hindi"],
    chinese: ["chinese", "mandarin", "cantonese"],
    malay: ["malay", "bahasa melayu", "bahasa malaysia"],
    tamil: ["tamil"],
    indonesian: ["indonesian", "bahasa indonesia"],
    japanese: ["japanese"],
    korean: ["korean"],
    french: ["french"],
    german: ["german"],
    spanish: ["spanish"],
    arabic: ["arabic"],
    thai: ["thai"],
    vietnamese: ["vietnamese"],
    russian: ["russian"],
    portuguese: ["portuguese"],
    italian: ["italian"],
    urdu: ["urdu"],
    bengali: ["bengali", "bangla"],
    telugu: ["telugu"],
    marathi: ["marathi"],
    punjabi: ["punjabi"],
    gujarati: ["gujarati"],
    kannada: ["kannada"],
    malayalam: ["malayalam"],
    tagalog: ["tagalog", "filipino"],
    dutch: ["dutch"]
  };
  function canonicalLanguage(text2) {
    const t = text2.toLowerCase();
    for (const [canon, names] of Object.entries(LANGUAGES)) if (names.some((n) => new RegExp(`\\b${n}\\b`).test(t))) return canon;
    return null;
  }
  function levelOf(words2) {
    const w = words2.toLowerCase();
    if (/\bnative|mother\s*tongue|bilingual/.test(w)) return "native";
    if (/\bnone\b|no\s+(knowledge|proficiency)|don'?t\s+(know|speak)/.test(w)) return "none";
    if (/\bbasic|beginner|elementary|limited|a1\b|a2\b/.test(w)) return "basic";
    if (/\bconversational|intermediate|working|b1\b|b2\b/.test(w)) return "conversational";
    return "fluent";
  }
  function parseLanguages(text2) {
    const out = /* @__PURE__ */ new Map();
    for (const chunk of (text2 ?? "").split(/[;\n]|,(?![^()]*\))/)) {
      const canon = canonicalLanguage(chunk.split(/[:\-–(]/)[0]);
      if (canon) out.set(canon, levelOf(chunk.replace(/^[^:\-–(]*/, "")));
    }
    return out;
  }
  var CONTEXT = /proficien|fluen|level|speak|spoken|read|writ|language|native|communicat|how well|command|ability|skill|understand/i;
  function languageAsked(label) {
    return CONTEXT.test(label) ? canonicalLanguage(label) : null;
  }
  var RANK = {
    native: [/native|bilingual|mother/i, /fluent/i, /full\s+professional/i, /advanced|proficient|expert/i],
    fluent: [/fluent/i, /full\s+professional/i, /native|bilingual/i, /advanced|proficient|expert|professional/i, /\bc[12]\b|excellent|very\s+good|high/i],
    conversational: [/conversational/i, /professional\s+working|working|intermediate/i, /\bb[12]\b|good/i],
    basic: [/basic|beginner|elementary|\ba[12]\b|limited|some/i],
    none: [/^\s*none\b|no\s+(knowledge|proficiency)|not\s+proficient|do\s+not\s+(know|speak)|don'?t\s+(know|speak)|not\s+at\s+all|^\s*no\s*$|^\s*0\s*$|zero/i]
  };
  var FREE_TEXT = { native: "Native", fluent: "Fluent (read, write and speak)", conversational: "Conversational", basic: "Basic", none: "None (no working knowledge)" };
  function languageAnswer(label, options, languages) {
    if (!(languages ?? "").trim()) return null;
    const lang = languageAsked(label);
    if (!lang) return null;
    const level = parseLanguages(languages).get(lang) ?? "none";
    const yes = options.find((o) => /^\s*yes\b/i.test(o)), no = options.find((o) => /^\s*no\b/i.test(o));
    const asksYesNo = /^\s*(do|can|are|have|would)\s+you\b/i.test(label);
    if (asksYesNo && (yes || options.length === 0)) return level === "none" || level === "basic" ? no ?? "No" : yes ?? "Yes";
    if (options.length === 0) return FREE_TEXT[level];
    for (const re of RANK[level]) {
      const hit = options.find((o) => re.test(o));
      if (hit) return hit;
    }
    return null;
  }

  // worker/match.ts
  function splitName(full) {
    const parts = full.trim().split(/\s+/);
    return { first: parts[0] ?? "", last: parts.slice(1).join(" ") };
  }
  var FAMILIES = [
    // sponsorship is the OPPOSITE question to "are you authorised": it must never borrow the authorisation answer
    ["sponsorship", /sponsor/i],
    ["notice", /notice\s*period|joining\s*time|how soon/i],
    ["expected_ctc", /expected.*(ctc|salary|compensation|pay)|salary\s*expectation|desired.*(salary|compensation)/i],
    ["current_ctc", /current.*(ctc|salary|compensation|pay)/i],
    ["visa", /visa|work\s*(authori[sz]ation|permit)|authori[sz]ed\s*to\s*work|eligible\s*to\s*work|right\s*to\s*work/i],
    ["relocate", /relocat/i]
  ];
  var COUNTRY_WORDS = {
    india: "in",
    indian: "in",
    singapore: "sg",
    singaporean: "sg",
    uae: "ae",
    emirates: "ae",
    dubai: "ae",
    australia: "au",
    australian: "au",
    "new zealand": "nz",
    uk: "gb",
    "united kingdom": "gb",
    british: "gb",
    england: "gb",
    ireland: "ie",
    irish: "ie",
    usa: "us",
    "united states": "us",
    america: "us",
    american: "us",
    canada: "ca",
    canadian: "ca",
    germany: "de",
    german: "de",
    netherlands: "nl",
    dutch: "nl",
    france: "fr",
    french: "fr",
    spain: "es",
    italy: "it",
    switzerland: "ch",
    hong: "hk",
    malaysia: "my",
    japan: "jp",
    qatar: "qa",
    "saudi arabia": "sa",
    eu: "eu",
    "european union": "eu"
  };
  function countriesIn(text2) {
    const l = text2.toLowerCase();
    return new Set(Object.entries(COUNTRY_WORDS).filter(([w]) => new RegExp(`\\b${w}\\b`).test(l)).map(([, code]) => code));
  }
  function sameCountryScope(question, bankQuestion) {
    const asked = countriesIn(question);
    if (asked.size === 0) return true;
    const answered = countriesIn(bankQuestion);
    return [...asked].every((c) => answered.has(c));
  }
  var family = (s) => FAMILIES.find(([, re]) => re.test(s))?.[0];
  var words = (s) => new Set(s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").split(/\s+/).filter((w) => w.length > 2));
  function matchAnswer(label, answers) {
    const fam = family(label);
    if (fam) {
      const hit = answers.find((a) => family(a.question) === fam && a.answer.trim() && (fam !== "visa" || sameCountryScope(label, a.question)));
      if (hit) return hit.answer;
      if (fam === "visa" || fam === "sponsorship") return null;
    }
    const lang = languageAsked(label);
    if (lang) return answers.find((a) => a.answer.trim() && languageAsked(a.question) === lang)?.answer ?? null;
    const skill = yearsSkill(label);
    if (skill) return answers.find((a) => a.answer.trim() && yearsSkill(a.question) === skill)?.answer ?? null;
    const lw = words(label);
    if (lw.size === 0) return null;
    let best = null;
    for (const a of answers) {
      if (!a.answer.trim()) continue;
      const aw = words(a.question);
      const inter = [...lw].filter((w) => aw.has(w)).length;
      const score = inter / (lw.size + aw.size - inter);
      if (!best || score > best.score) best = { score, answer: a.answer };
    }
    return best && best.score >= 0.5 ? best.answer : null;
  }
  function standardValue(label, a) {
    const l = label.toLowerCase();
    const { first, last } = splitName(a.name);
    if (/first\s*name|given\s*name/.test(l)) return first;
    if (/last\s*name|surname|family\s*name/.test(l)) return last;
    if (/^\s*(your\s*|full\s*|legal\s*)*name\s*[*:]*\s*$/.test(l.replace(/\sq\d+$/, "")) || /\b(full|legal)\s*name\b/.test(l)) return a.name;
    if (/e-?mail/.test(l)) return a.email;
    if (/phone|mobile|contact\s*number/.test(l)) return a.phone;
    if (/linkedin/.test(l)) return a.links.find((u) => /linkedin\.com/i.test(u)) ?? null;
    if (/github/.test(l)) return a.links.find((u) => /github\.com/i.test(u)) ?? null;
    if (/\bportfolio\b|\bwebsite\b|personal\s*site|\burl\b/.test(l)) return a.links.find((u) => !/linkedin\.com/i.test(u)) ?? null;
    if (/current\s*(company|employer)/.test(l)) return a.currentCompany ?? null;
    if (/\blocation\b|\bcity\b|where.*(based|located)/.test(l) && !/relocat/.test(l)) return a.location || null;
    return null;
  }

  // src/lib/apply/consent.ts
  var CONSENT_BOX = /\b(i\s+(have\s+read|agree|accept|consent|acknowledge|understand|confirm|certify|authori[sz]e)|terms|privacy|consent|data\s+(protection|processing)|gdpr|agree|acknowledg|accurate|true\s+and\s+(correct|complete)|declaration)\b/i;

  // src/lib/apply/safety.ts
  var PASSWORD = /\b(confirm(ation)?\s+|re-?enter\s+|retype\s+|new\s+|create\s+|choose\s+|set\s+)?(password|passcode|passphrase)\b/i;
  var PAYMENT = /\b(card\s*(number|no)|credit\s*card|debit\s*card|cvv|cvc|security\s*code|expir(y|ation)\s*date|bank\s*account|iban|routing\s*number|sort\s*code|upi\s*id)\b/i;
  var IDENTITY = /\b(ssn|social\s*security|aadhaar|aadhar|pan\s*(card|number)|passport\s*(number|no)|national\s*(id|identity)|nric|driver'?s\s*licen[cs]e|tax\s*id)\b/i;
  var CODE = /\b(one[- ]time\s*(code|password|pin)|otp|verification\s*code|authenticator|2fa|two[- ]factor)\b/i;
  function sensitiveKind(label, type = "text") {
    if (type.toLowerCase() === "password") return "password";
    if (/^\s*(how many|years?\b|number of)/i.test(label)) return null;
    if (PASSWORD.test(label)) return "password";
    if (CODE.test(label)) return "code";
    if (PAYMENT.test(label)) return "payment";
    if (IDENTITY.test(label)) return "identity";
    return null;
  }

  // src/lib/apply/demographics.ts
  var DEMOGRAPHIC = /\b(gender|sex\b|race|racial|ethnic|ethnicity|hispanic|latino|veteran|military|disabilit|disabled|sexual\s+orientation|lgbt|pronoun|religio|marital|date\s+of\s+birth|birth\s*date|\bage\b|caste|nationality\s+group)/i;
  var DECLINE = /(decline|prefer\s+not|rather\s+not|do\s+not\s+wish|don'?t\s+wish|not\s+to\s+(say|disclose|answer|identify)|choose\s+not|i\s+do\s+not\s+want|no\s+answer|not\s+disclosed?)/i;
  var isDemographic = (label) => DEMOGRAPHIC.test(label);
  function declineOption(label, options) {
    if (!isDemographic(label)) return null;
    return options.find((o) => DECLINE.test(o)) ?? null;
  }

  // extension/src/content.ts
  var visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
  };
  var text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  var clean = (s) => s.replace(/[*✱]/g, "").replace(/\s+/g, " ").trim();
  function labelOf(el) {
    const al = el.getAttribute("aria-label");
    if (al) return al;
    const by = el.getAttribute("aria-labelledby");
    if (by) {
      const t = by.split(/\s+/).map((id) => text(document.getElementById(id))).join(" ").trim();
      if (t) return t;
    }
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) return text(l);
    }
    const wrap = el.closest("label");
    if (wrap) return text(wrap);
    return el.getAttribute("placeholder") || el.name || "";
  }
  function groupLabelOf(el) {
    const fs = el.closest("fieldset");
    const legend = fs?.querySelector("legend");
    if (legend) return text(legend);
    const grp = el.closest("[role=radiogroup],[role=group]");
    if (grp?.getAttribute("aria-label")) return grp.getAttribute("aria-label");
    const gby = grp?.getAttribute("aria-labelledby");
    if (gby) {
      const t = gby.split(/\s+/).map((id) => text(document.getElementById(id))).join(" ").trim();
      if (t) return t;
    }
    return text(el.closest("div")?.parentElement?.querySelector("label,legend,p,span") ?? null);
  }
  function setValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  var norm = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
  function pick(options, answer) {
    const a = norm(answer);
    const yn = /^\s*(yes|y|true)\b/i.test(answer) ? "yes" : /^\s*(no|n|false)\b/i.test(answer) ? "no" : null;
    let i = options.findIndex((o) => norm(o) === a);
    if (i < 0 && yn) i = options.findIndex((o) => norm(o).startsWith(yn));
    if (i < 0) i = options.findIndex((o) => norm(o).includes(a) || norm(o).length > 2 && a.includes(norm(o)));
    return i;
  }
  var flag = (el) => {
    el.style.outline = "2px solid #f97316";
    el.style.outlineOffset = "2px";
  };
  function fillPage(data) {
    const out = { filled: [], forYou: [], secret: [] };
    const profile = { experience: data.experience.map((e, i) => ({ id: `e${i}`, company: "", title: e.title, start: e.start, end: e.end, bullets: e.bullets.map((t, j) => ({ id: `b${i}.${j}`, text: t })) })) };
    const answers = data.answers;
    const dialog = [...document.querySelectorAll('[role="dialog"], dialog[open], [aria-modal="true"]')].find(visible);
    const root = dialog ?? document;
    const controls = [...root.querySelectorAll("input, textarea, select")].filter((e) => {
      const t = (e.type || "").toLowerCase();
      return !["hidden", "submit", "button", "image", "reset", "file"].includes(t) && !e.disabled && !e.readOnly && visible(e) && !e.closest("header, nav, [role=search]");
    });
    const done = /* @__PURE__ */ new Set();
    const valueFor = (label, options) => {
      const std = standardValue(label, data.applicant);
      if (std) return std;
      const banked = matchAnswer(label, answers);
      if (banked) return banked;
      const skill = yearsSkill(label);
      if (skill) return skillYears(profile, skill) ?? defaultToolYears(profile, skill);
      return languageAnswer(label, options, data.languages) ?? declineOption(label, options);
    };
    for (const el of controls) {
      const type = el.tagName === "SELECT" ? "select" : el.tagName === "TEXTAREA" ? "textarea" : (el.type || "text").toLowerCase();
      const required = el.required || el.getAttribute("aria-required") === "true" || /[*✱]/.test(labelOf(el));
      if (type === "radio") {
        const group = el.name || labelOf(el);
        if (done.has(group)) continue;
        done.add(group);
        const members = [...root.querySelectorAll(`input[type=radio]${el.name ? `[name="${CSS.escape(el.name)}"]` : ""}`)].filter(visible);
        if (members.some((m) => m.checked)) continue;
        const label2 = clean(groupLabelOf(el));
        const opts = members.map((m) => clean(labelOf(m)));
        const v2 = label2 ? valueFor(label2, opts) : null;
        const i = v2 ? pick(opts, v2) : -1;
        if (i >= 0) {
          members[i].click();
          out.filled.push(label2);
        } else if (required && label2) {
          out.forYou.push(label2);
          members.forEach(flag);
        }
        continue;
      }
      if (type === "checkbox") {
        const label2 = clean(labelOf(el));
        if (required && !el.checked && CONSENT_BOX.test(label2)) {
          el.click();
          out.filled.push(label2);
        } else if (required && !el.checked && label2) {
          out.forYou.push(`${label2} (a box that is not a plain agreement)`);
          flag(el);
        }
        continue;
      }
      const label = clean(labelOf(el) || groupLabelOf(el));
      if (!label) continue;
      const secret = sensitiveKind(label, type);
      if (secret) {
        out.secret.push(label);
        flag(el);
        continue;
      }
      if (type === "select" ? !!el.value && !/^\s*(select|choose)/i.test(el.selectedOptions[0]?.text ?? "") : !!el.value) continue;
      const options = type === "select" ? [...el.options].map((o) => o.text.trim()).filter((t) => t && !/^\s*(please\s+)?(select|choose)\b/i.test(t)) : [];
      let v = valueFor(label, options);
      if (v != null && type !== "select" && wantsNumber(label)) v = asCount(v);
      if (v == null) {
        if (required) {
          out.forYou.push(label);
          flag(el);
        }
        continue;
      }
      if (type === "select") {
        const sel = el;
        const i = pick([...sel.options].map((o) => o.text.trim()), v);
        if (i >= 0) {
          setValue(sel, sel.options[i].value);
          out.filled.push(label);
        } else if (required) {
          out.forYou.push(label);
          flag(el);
        }
      } else {
        setValue(el, v);
        out.filled.push(label);
      }
    }
    return out;
  }
  var KIND_WORDS = (el) => {
    const own = [labelOf(el), el.name, el.id, el.getAttribute("accept") ?? ""].join(" ").toLowerCase();
    if (/resume|\bcv\b|curriculum|cover/.test(own)) return own;
    let box = el.parentElement, near = "";
    for (let i = 0; i < 4 && box && box.querySelectorAll('input[type="file"]').length === 1; i++, box = box.parentElement) {
      const t = text(box);
      if (t.length > 0 && t.length <= 240) {
        near = t;
        break;
      }
    }
    return `${own} ${near}`.toLowerCase();
  };
  function toFile(f) {
    const bin = atob(f.b64), bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], f.name, { type: f.type });
  }
  function attachFiles(resume, cover) {
    const out = { attached: [], missing: [] };
    const inputs = [...document.querySelectorAll('input[type="file"]')].filter((e) => !e.disabled);
    const give = (el, f) => {
      const dt = new DataTransfer();
      dt.items.add(toFile(f));
      el.files = dt.files;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      out.attached.push(f.name);
    };
    const free = inputs.filter((e) => !e.files?.length);
    const isCover = (e) => /cover/.test(KIND_WORDS(e));
    const isResume = (e) => !isCover(e) && /resume|\bcv\b|curriculum/.test(KIND_WORDS(e));
    if (resume) {
      const target = free.find(isResume) ?? (inputs.length === 1 && free.length === 1 && !isCover(free[0]) ? free[0] : void 0);
      if (target) give(target, resume);
      else out.missing.push(inputs.length ? "no file box on this page asks for a resume" : "this page has no file box yet (if it has an Upload or Attach button, press it once, then fill again)");
    }
    if (cover) {
      const target = free.find((e) => isCover(e) && !e.files?.length);
      if (target) give(target, cover);
    }
    return out;
  }
  window.__careerAgentFill = fillPage;
  window.__careerAgentAttach = attachFiles;
})();
