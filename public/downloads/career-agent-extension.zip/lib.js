"use strict";
(() => {
  // src/lib/extension/link-code.ts
  function parseToken(token) {
    const m = (token ?? "").trim().match(/^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|legacy)\.([0-9a-f]{48})$/i);
    return m ? { profileId: m[1].toLowerCase(), secret: m[2].toLowerCase() } : null;
  }
  function parseLinkCode(code) {
    const [origin, token, extra] = (code ?? "").trim().split("|");
    if (extra !== void 0 || !origin || !token) return null;
    try {
      const u = new URL(origin);
      if (u.protocol !== "https:" && !(u.protocol === "http:" && /^(localhost|127\.0\.0\.1)$/.test(u.hostname))) return null;
      if (!parseToken(token)) return null;
      return { origin: u.origin, token };
    } catch {
      return null;
    }
  }

  // src/lib/extension/queue.ts
  function itemForPage(queue, pageUrl) {
    let host;
    try {
      host = new URL(pageUrl).hostname.replace(/^www\./, "");
    } catch {
      return null;
    }
    const same = queue.filter((q) => {
      try {
        return new URL(q.formUrl).hostname.replace(/^www\./, "") === host;
      } catch {
        return false;
      }
    });
    return same.find((q) => q.resume) ?? same[0] ?? null;
  }

  // extension/src/lib.ts
  var parts = (v) => v.split(".").map((n) => parseInt(n, 10) || 0);
  function isNewer(latest, current) {
    if (!latest) return false;
    const a = parts(latest), b = parts(current);
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
    }
    return false;
  }
  globalThis.CareerAgentLib = { parseLinkCode, itemForPage, isNewer };
})();
